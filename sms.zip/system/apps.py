from django.apps import AppConfig


class SystemConfig(AppConfig):
    name = 'system'
